add matlab
matlab -ver 7.14 -nodisplay -nosplash -r "project_part_II; exit;"
