function shotgun_seqs = s_to_shotgun(s, num_shotgun, l_shotgun)
    shotgun_seqs = reshape(s, num_shotgun, l_shotgun);
end